export const apiCall = async (URL)=>{
   const response =  await fetch(URL);
   const json = await response.json();
   console.log('Product JSON is ', json);
   return json;
}