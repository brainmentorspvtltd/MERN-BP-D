import { apiCall } from "../../../shared/services/api-client.js"
import { PRODUCT_URL } from "../../../shared/utils/config.js"
import Product from "../models/product.js";

// Bring the Products from the BackEnd Api


export const productOperations = {
    products :[],
      async getProducts(){
        console.log('this is ', this);
        const rawProducts = await apiCall(PRODUCT_URL);
        this.products = rawProducts.map(product=>
            new Product(product.id, product.title, 
                product.description,product.price, product.image));
        console.log('Products are ', this.products);
        return this.products;
    },
    searchProduct (productId){
     return this.products.find(product=>product.id == productId);
    }

}     
