// add to cart, remove from cart, view cart
export const cartOperations = {
    carts:[],
    addToCart(product){
        this.carts.push(product);
        console.log('Items in cart ', this.carts);
    },
    viewCart(){
        return this.carts;
    }
}
