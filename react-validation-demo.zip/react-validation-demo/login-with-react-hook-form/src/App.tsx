

import Dynamic from './components/Dynamic'
import Login from './components/Login'

function App() {
  return (<Dynamic/>)
 // return (<Login/>)
}

export default App
