import { useFieldArray, useForm } from "react-hook-form";
type Task= {
    name:string;
    desc:string;
}
type Forms = {
    tasks:Task[]; // array of objects
}
const Dynamic = ()=>{
    const {register, handleSubmit, formState:{errors, isDirty, dirtyFields, isLoading, isSubmitted, isSubmitting}, control} = useForm<Forms>({
        defaultValues:{tasks:[{name:'',desc:''}]}
    });
    const {append, remove, fields} = useFieldArray({name:'tasks', control});
    const addNewForm = ()=>{
        append({name:'', desc:''});
    }
    const onSubmit = (form:Forms)=>{
        console.log('Form Submit ', form);
    }
    return (<div>
        <button onClick={addNewForm}>Add New Task</button>
        <br />
        <form onSubmit={handleSubmit(onSubmit)}>
            {fields.map((field,index)=>{
                return (
                    <div key={index}>
                        <hr />
                <div>
                    <label htmlFor="">TaskName</label>
                    <input {...register(`tasks.${index}.name`, {required:'Task Name is Empty', pattern:{value:/^[a-zA-Z]{3,10}$/, message:'Invalid Task Name'}})} type="text" placeholder="Type Task Name" />
                    {errors.tasks && errors.tasks[index]?.name && errors.tasks[index].name.message && <p style= {{color:'red'}}>{errors.tasks[index].name.message}</p>}
                </div>
                <div>
                    <label htmlFor="">Task Desc</label>
                    <input {...register(`tasks.${index}.desc`)} type="text" placeholder="Type Task Desc" />
                </div>
                <button onClick={()=>{
                   remove(index); 
                }}>Remove</button>
            </div>
                )
            })}
            <br />
            <button>Save All</button>
        </form>
    </div>)
}
export default Dynamic;