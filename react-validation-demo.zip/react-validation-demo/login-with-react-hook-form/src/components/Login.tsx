import { useForm } from "react-hook-form";
import User from "../models/user";

const Login = ()=>{
    const {register, handleSubmit, formState:{errors}} = useForm<User>();
    const mySubmit = (user:User)=>{
        console.log('Form Submit ', user);
    }
    return (<div>
        <h1>Login</h1>
        <form onSubmit={handleSubmit(mySubmit)}>
            <div>
                <label>UserName</label>
                <input {...register("username",
                {
                    required:"UserName can't be blank",
                 pattern:{
                    value:/^[a-zA-Z][a-zA-Z0-9]{3,10}$/,
                    message:'Invalid UserName'
                    }
                    })} type="text" placeholder="Type username here" />
            {errors.username && errors.username.message && <p style={{color:'red'}}>{errors.username.message}</p> }
            </div>
            <div>
                <label >Password</label>
                <input {...register('password', {
                    required:"Password Can't Be Blank",
                     maxLength:{value:25, message:'Password is Too Long'},
                      minLength:{value:8, message:'Password is too short'}})} type="password" placeholder="Type Password Here" />
                {errors.password && errors.password.message && <p style={{color:'red'}}>{errors.password.message}</p>}
            </div>
            <div>
                <button>Submit</button>
            </div>
        </form>
    </div>)
}
export default Login;