import { ChangeEvent, FormEvent, useRef, useState } from "react";
import { User } from "../models/user";
import { doLogin } from "../services/api-client";

const Login = ()=>{
    const userNameRef = useRef<HTMLInputElement>(null);
    const passwordRef = useRef<HTMLInputElement>(null);
    const [message, setMessage] = useState<string>('');
    const [error, setError] = useState({errorUserName:'', errorPassword:''});
    const takeUserName = (event:ChangeEvent<HTMLInputElement>)=>{
        const userName = event.target.value;
        validateUserName(userName);
    }
    const takePassword = (event:ChangeEvent<HTMLInputElement>)=>{
        const password = event.target.value;
        validatePassword(password);
    }
    const validateUserName = (userName:string)=>{
        if(userName.trim().length==0){
            setError({...error, errorUserName:"UserName Can't Be Blank"});
            console.log('Blank Call for UserNAme');
            return "UserName Can't Be Blank";
        }
        const pattern = /^[a-zA-Z][a-zA-Z0-9]{3,10}$/;
        const regEx = new RegExp(pattern);
        if(!regEx.test(userName)){
            setError({...error, errorUserName:"UserName is Invalid"});
            return "UserName is Invalid";
        }
        setError({...error, errorUserName:""});
        return "";
    }

    const validatePassword= (password:string)=>{
        if(password.trim().length==0){
            setError({...error, errorPassword:"Password Can't Be Blank"});
            return "Password Can't Be Blank";
        }
        if(password.length<8){
            setError({...error, errorPassword:"Password is Too Small"});
            return "Password is Too Small";
        }
        if(password.length>25){
            setError({...error, errorPassword:"Password is Too Large"});
            return "Password is Too Large";
        }
        setError({...error, errorPassword:""});
        return "";
    }

    const mySubmit = async (event:FormEvent)=>{
        event.preventDefault();
        const userName = userNameRef?.current?.value;
        const password = passwordRef?.current?.value;
        const error1 = validateUserName(userName!);
        const error2 = validatePassword(password!);
        if(error1.trim().length>0 || error2.trim().length>0){
            setError({errorUserName:error1, errorPassword:error2});
        }
        else{
            // form is valid, do api call
            console.log('UserName is ', userName);
        console.log('Password is ', password);
        const user:User = {username:userName!,password:password!};
        const data = await doLogin(user);
        console.log('Data is from API ', data);    
        if(data && data.message){
            setMessage('Invalid UserName or Password');
        }
        else{
            setMessage('Welcome '+data.firstName);
        }
        }
        
    }
        
           
    
    return (<div>
        <h1>LOGIN</h1>
        <h2>{message}</h2>
        <form onSubmit={mySubmit}>
            <div>
                <label htmlFor="">UserName</label>
                <input ref = {userNameRef} onChange={takeUserName} type="text" placeholder="Type UserName Here" />
               {error.errorUserName && <p style = {{color:'red'}}>{error.errorUserName}</p>}
            </div>
            <div>
                <label htmlFor="">Password</label>
                <input ref = {passwordRef} type="password" onChange={takePassword} placeholder="Type Password Here" />
                {error.errorPassword && <p style = {{color:'red'}}>{error.errorPassword}</p>}
            </div>
            <div>
                <button>Login</button>
                &nbsp;
                <button>Reset</button>
            </div>
        </form>
    </div>)
}
export default Login;