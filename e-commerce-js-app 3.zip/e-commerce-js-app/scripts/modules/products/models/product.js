// Model for the Product
// Id , Name, Price, Discount, Desc , Qty
class Product{
    constructor(id=0, name="", desc="", price=0.0, image=""){
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.price = price;
        this.image = image;
    }
}
export default Product;