const printProduct =(product)=>{
    console.log('Current Product is ', product);
    const img = document.createElement('img');
    img.src = product.image;
    img.style.width = '300px';
    img.style.height = '300px';
    const pTag = document.createElement('p');
    pTag.innerText = product.name;
    const pTagForDesc = document.createElement('p');
    pTagForDesc.innerText = product.desc;
    const productDiv = document.querySelector('#product');
    productDiv.appendChild(img);
    document.querySelector('#title').innerText = product.name;
    //productDiv.appendChild(pTag);
    productDiv.appendChild(pTagForDesc);
    const pTagForPrice = document.createElement('p');
    pTagForPrice.innerHTML = `&#8377; ${product.price}`;
    productDiv.appendChild(pTagForPrice);
}

const lookUpProduct = (id, products)=>{
    const currentProduct = products.find(product=>product.id == id);
    printProduct(currentProduct);
}


const getProductId = ()=>{
    const url = new URLSearchParams(location.href);
    const productId = url.entries().next().value[1];
    const products = JSON.parse(localStorage.products);
    console.log('Products ', products);
    console.log('Product Id ', productId);
    lookUpProduct(productId, products);
}
getProductId();

