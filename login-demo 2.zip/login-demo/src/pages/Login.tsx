import { ChangeEventHandler, useRef, useState } from "react";
import Text from "../components/Text";
import TextBox from "../components/TextBox";
import Button from "../components/Button";
import User from "../model/User";
import doLogin from "../services/api-client";

type ErrorFields = {
    user:string;
    password:string;
    phone:string;
    isValid:boolean;
}

const Login = ()=>{
    const userIdRef= useRef<HTMLInputElement>();
    const passwordRef = useRef<HTMLInputElement>();
    const phoneRef= useRef<HTMLInputElement>();
    const [isSubmit, setSubmit] = useState<boolean>(false);
    const [error, setError] = useState<ErrorFields>({user:'', password:'', phone:'', isValid:false});
    // {useridError:'',password}
    //const [errorMessage , setErrorMessage] = useState<string>("");
    const takeUserInput = (event:React.ChangeEvent<HTMLInputElement>)=>{
        // event = Which event happens
        // target = where happens (textbox e.g input type='text')
        // target give source 
        // value - textbox value
        const userid = event.target.value;
        const errorMsg = userIdValidation(userid);
        setError({...error, user:errorMsg});
       
        //console.log('User Input ', userid);
    }
    const takePasswordInput = (event:React.ChangeEvent<HTMLInputElement>)=>{
        const password = event.target.value;
        
       
        //console.log('Password Input ', password);
    }

    const takePhoneInput = (event:React.ChangeEvent<HTMLInputElement>)=>{
        const phone = event.target.value;
        
        const errorMsg = phoneValidation(phone);
        setError({...error, phone:errorMsg});
       
        //console.log('Password Input ', password);
    }
    const phoneValidation = (phone:string)=>{
        const pattern = /^[0-9]{10}$/;
        const r=new RegExp(pattern);
        console.log('Phone Pattern ', r.test(phone));
        if(r.test(phone)){
            return "";
        }
        else{
            return "Invalid Phone Number ";
        }
    }

    const userIdValidation =(userid:string)=>{
        if(userid.length<3){
            return "Userid Require Min 3 Chars";
        }
        if(userid.length>25){
            return "Userid can't be greater than 25 chars";
        }
        //pattern = /^/d+$/
        //pattern = /^[0-9]{3,10}$/
        const pattern = /^[a-zA-Z][a-zA-Z0-9]*$/;
        const r=new RegExp(pattern);
        console.log('USER ID VALIDATON Pattern ', r.test(userid));
        if(r.test(userid)){
            return "";
        }
        else{
            return "Invalid Userid ";
        }
    }

    const mySubmit = async (event:React.FormEvent)=>{
        event.preventDefault();
        const userid:string = userIdRef.current?.value!;
        const password:string = passwordRef.current?.value!;
        const phone:string = phoneRef.current?.value!;
       
        const userErrorMsg = userIdValidation(userid);
        const phoneErrorMsg = phoneValidation(phone);
        const isValid = userErrorMsg.length ==0 && phoneErrorMsg.length==0;
        
        setError({...error, user: userErrorMsg, phone:phoneErrorMsg, isValid});
        console.log('MY SUBMIT Form Submit... '+userid+" "+password +" "+phone);
        setSubmit(true);
        if(isValid){
           try{
            const user:User = {userid, password, phone};
            
            const result  = await doLogin(user);
            console.log('********* Result from API ', result);
            //alert("stop");
            //console.log('Result from API Call ', result);
                console.log('Form Submit...');
            //console.log('Form Result is ', result);
           }
           catch(err){
            console.log('Error is ', err);
            event.preventDefault();
           }

        }
        //alert("stop");
        event.preventDefault();
        console.log('Form Done...');
    }

    return (<form onSubmit={mySubmit}>
        {isSubmit && <div style={{color:'red'}}>
            <p>{error.user}</p>
            <p>{error.phone}</p>
        </div>}
        <h1>Login </h1>
        <Text lbl="Userid"/>
        <TextBox myref={userIdRef} fieldType="text" placeHolder="Type Userid Here" 
        fn={takeUserInput} />
        <Text lbl = {error.user}/>    
        <br />
        <Text lbl = "Password"/>
        <TextBox myref={passwordRef} fieldType="password" placeHolder="Type Password Here" 
        fn={takePasswordInput} />
        <br />
        
        <Text lbl = "Phone"/>
        <TextBox myref={phoneRef} fieldType="text" placeHolder="Type Phone Here" 
        fn={takePhoneInput} />
        <Text lbl = {error.phone}/> 
        <br />
        <Button label="Login"/>
        &nbsp;
        <Button label="Reset"/>
    </form>);
}
export default Login;