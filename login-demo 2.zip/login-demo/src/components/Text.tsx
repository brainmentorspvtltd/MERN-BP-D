
const Text = ({lbl}:{lbl:string})=>{
    return (<label>{lbl}</label>)
}
export default Text;