import { ChangeEventHandler } from "react";

type TextField = {
    fieldType:string;
    placeHolder:string;
    fn:ChangeEventHandler<HTMLInputElement>;
    myref: any;
}
const TextBox = (props:TextField)=>{
    return (<input ref = {props.myref} type = {props.fieldType} 
        placeholder={props.placeHolder} onChange={props.fn}/>);
}
export default TextBox;