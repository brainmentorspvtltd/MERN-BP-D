import User from "../model/User";

const doLogin = async (user:User)=>{
    // username = emilys
    // pwd = emilyspass
    const obj = {username:user.userid, password: user.password, phone: user.phone};
    console.log('************** Obj User is ', obj);
    //alert("Stop");
    try{
    const response = await fetch('https://dummyjson.com/auth/login', {
        method: 'POST',
        headers: {
            "Content-Type": "application/json",
          },
        body: JSON.stringify(obj),
      
      });
      //alert("Stop2");
      console.log('Response is ', response);
      const result = await response.json();
      console.log('Result is ', result);
      //alert("STOP...");
      return result;
    }
    catch(err){
        console.log('API Error is ', err);
    }
      
      
}
export default doLogin;