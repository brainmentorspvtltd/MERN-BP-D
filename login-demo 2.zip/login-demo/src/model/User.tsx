type User = {
    userid:string;
    password:string;
    phone:string;
}
export default User;