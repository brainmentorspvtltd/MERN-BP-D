export const getNewJoke = async ()=>{
   // console.log('ENV ', import.meta.env.VITE_JOKE_URL);
    const response = await fetch(import.meta.env.VITE_JOKE_URL);
    return response.json();
}