import { Text } from "./components/Text"
import { JokeView } from "./pages/JokeView"



function App() {
  

  return (
    <JokeView/>
  )
}

export default App
