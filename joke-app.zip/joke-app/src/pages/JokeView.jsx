import { useEffect, useState } from "react"
import { Button } from "../components/Button"
import { Text } from "../components/Text"
import { getNewJoke } from "../services/api-client"


export const JokeView = () => {
    useEffect(()=>{
        getJoke();
    },[]); // Mounting

    // useEffect(()=>{

    // }); // Updation of all state of this component

    // useEffect(()=>{

    // }, [a,b]); // Updation of a,b of this component

    // useEffect(()=>{
    //     return function(){

    //     }
    // },[]); // UnMouting
    const [joke, setJoke] = useState({question:'', answer:''});
    const getJoke= async ()=>{
        const data = await getNewJoke();
        setJoke({question:data.setup, answer:data.punchline});
        console.log('Data ' , data.setup , data.punchline);
    }
  return (
    <div style={{marginLeft:'20px'}}>
    <Text joke = {joke}/>    
    <Button fn = {getJoke}/>
    </div>
  )
}
