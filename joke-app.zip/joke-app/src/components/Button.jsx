export const Button = ({fn})=>{
    return (<button onClick={fn}>Get New Joke</button>)
}