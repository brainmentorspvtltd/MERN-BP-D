

export const Text = ({joke}) => {
    console.log('Text ', joke);
  return (
    <>
    <h2>😎 &nbsp;{joke.question}</h2>
    <h3>😂 &nbsp; {joke.answer}</h3>
    </>
    )   
}
