import {z} from 'zod';
export const userSchema = z.object({
    email:z.string().email('Invalid Email'),
    password:z.string()
    .min(8, 'Password Min Length is 8 chars')
    .max(25,'Password Max Len Not more than 25 chars')
    .regex(/[A-Z]/,'Password Must contain at least one Uppercase letter')
    .regex(/[a-z]/, 'Password must contains at least one small letter')
    .regex(/\d/,'Password must contains at least one digit')
    .regex(/[@$_-]/, 'Password must contains a one special Char'),
    age:z.number().optional(),
    gender:z.string().min(1,'Gender is Required'),
    country:z.string().nonempty('Country is Required'),
    confirmPassword : z.string()
    
}).refine(data=>data.password=== data.confirmPassword, {message:'Password and Confirm Password must be same',path:['confirmPassword']});
export type UserSchema = z.infer<typeof userSchema>
// z.infer TS Type utility analyze and rules apply