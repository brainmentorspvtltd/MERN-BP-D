import Register from './components/Register'
import UserRegister from './components/UserRegister'

function App() {

  // return (<Register/>)
  return (<UserRegister/>)
}

export default App
