import { ChangeEvent, FormEvent, useState } from "react";
import { userSchema } from "../schema/user-schema";
import './Register.css';
type RegisterFormFields = {
    email:string;
    password:string;
    confirmPassword:string;
    gender:string;
    country:string;

}
const Register = ()=>{
    const [formFields, setFormFields] =useState<RegisterFormFields>({email:'', password:'', confirmPassword:'', gender:'',country:''});
    const [errors, setErrors] = useState<Record<string, string>>({});
    const takeInput = (event:ChangeEvent<HTMLInputElement | HTMLSelectElement>)=>{
        const fieldName = event.target.name;
        const fieldValue = event.target.value;
        setFormFields({...formFields, [fieldName]:fieldValue})
    }
    const doSubmit = (event:FormEvent)=>{
        event.preventDefault();
        const result = userSchema.safeParse(formFields);
        if(!result.success){
            const fieldErrors: Record<string, string> = {};
            
            result.error.errors.forEach(error=>{
                console.log('Error ', error);
                fieldErrors[error.path[0]] = error.message;
            });
            setErrors(fieldErrors);
            return ;
        }
        setErrors({});
    }
    return (<div>
        <h2>Register</h2>
        <form onSubmit={doSubmit}>
            <div>
                <label htmlFor="">Email</label>
                <input onChange={takeInput} name="email" type="text" placeholder="Type Email Here" />
                {errors.email && <p>{errors.email}</p>}
            </div>
            <div>
                <label htmlFor="">Password</label>
                <input onChange={takeInput} name="password" type="password" placeholder="Type Password Here" />
                {errors.password && <p>{errors.password}</p>}
            </div>
            <div>
                <label htmlFor="">Password</label>
                <input onChange={takeInput} name="confirmPassword" type="password" placeholder="Type Confirm Password Here" />
                {errors.confirmPassword && <p>{errors.confirmPassword}</p>}
            </div>
            <div>
                <label htmlFor="">Gender</label>
                <input onChange={takeInput} name="gender" type="radio" value="M" /> Male
                <input onChange={takeInput} name="gender" type="radio" value="F" /> Female
                {errors.gender && <p>{errors.gender}</p>}
            </div>
            <div>
                <label htmlFor="">Country</label>
               <select onChange={takeInput} name="country">
                <option value="" disabled selected>Select Country</option>
                {["India", "USA", "China", "Srilanka"].
                map((country, index)=><option key={index} value={country}>{country}</option>)}
               </select>
               {errors.country && <p>{errors.country}</p>}
            </div>
            <div>
                <button>Register</button>
            </div>
        </form>
    </div>)
}
export default Register;