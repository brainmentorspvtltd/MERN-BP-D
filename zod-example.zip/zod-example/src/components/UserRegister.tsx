
import { UserSchema, userSchema } from "../schema/user-schema";
import './Register.css';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMemo } from "react";

const UserRegister = useMemo(()=>{
    const {register, handleSubmit, formState:{errors}} = useForm<UserSchema>({resolver:zodResolver(userSchema)});
   
    const doSubmit = (form:UserSchema)=>{
        console.log('User Data ', form);
       
    }
    return (<div>
        <h2>Register</h2>
        <form onSubmit={handleSubmit(doSubmit)}>
            <div>
                <label htmlFor="">Email</label>
                <input {...register('email')} type="text" placeholder="Type Email Here" />
                {errors.email && <p>{errors.email.message}</p>}
            </div>
            <div>
                <label htmlFor="">Password</label>
                <input {...register('password')} type="password" placeholder="Type Password Here" />
                {errors.password && <p>{errors.password.message}</p>}
            </div>
            <div>
                <label htmlFor="">Password</label>
                <input {...register('confirmPassword')} type="password" placeholder="Type Confirm Password Here" />
                {errors.confirmPassword && <p>{errors.confirmPassword.message}</p>}
            </div>
            <div>
                <label htmlFor="">Gender</label>
                <input {...register('gender')} type="radio" value="M" /> Male
                <input {...register('gender')} type="radio" value="F" /> Female
                {errors.gender && <p>{errors.gender.message}</p>}
            </div>
            <div>
                <label htmlFor="">Country</label>
               <select {...register('country')}>
                <option value="" disabled selected>Select Country</option>
                {["India", "USA", "China", "Srilanka"].
                map((country, index)=><option key={index} value={country}>{country}</option>)}
               </select>
               {errors.country && <p>{errors.country.message}</p>}
            </div>
            <div>
                <button>Register</button>
            </div>
        </form>
    </div>)
},[]);
export default UserRegister;