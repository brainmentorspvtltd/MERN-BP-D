import { User } from "../models/user";

export const doLogin = async (user:User)=>{
   const response = await fetch(import.meta.env.VITE_LOGIN_URL,{
        method:'POST',
        body:JSON.stringify(user),
        headers:{'Content-Type':'application/json'}
    });
    const data = await response.json();
    return data;

}