//Bridge file b/w index.html and App.jsx
import {createRoot} from 'react-dom/client';
import App from './App';
const rootDiv = document.querySelector('#root'); // dom
const root = createRoot(rootDiv);
root.render(<App/>); // App()

// <App/>  --> App() --> JSX --> React.createElement --> object --> object tree--> VDOM --> ReactDOM --> DOM