// What is Component?
//Small View/UI
// JS Function Having JSX
// JSX - 99% HTML Like
// JavaScript and XML
import './App.css';
import { Menu } from './components/Menu';
function App(){
  let products = ["shoes","shirt","tie"];
  let name = "Amit";
  let isLogin = false;
  const myStyle = {color:isLogin?'red':'blue', backgroundColor:'green'};
  return (<div><h1 style={myStyle}>Hello React JS {name}</h1>
  {isLogin?<button>Logout</button>:<button>Login</button>}
  <p>Iterative Rendering</p>
  {products.map(pr=><p>{pr}</p>)}
  <h2 className='yellow'>hi react js</h2>
  <button onClick = {()=>{

  }}></button>
  <Menu/>
  </div>);
 // return React.createElement('h1',null, 'Hello React JS');
}
export default App;