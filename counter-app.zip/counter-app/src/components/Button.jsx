

export const Button = ({val, fn}) => {
    console.log('Button Component');
  return (
    <button onClick={fn}>{val}</button>
  )
}

