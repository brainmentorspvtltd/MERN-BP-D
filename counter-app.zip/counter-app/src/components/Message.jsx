import React from 'react'

export const Message = (props) => {
    console.log('Message Component');
  return (
    <h1 >{props.msg} {props.val}</h1>
  )
}
