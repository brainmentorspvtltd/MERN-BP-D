import { useState } from "react";
import { Button } from "../components/Button"
import { Message } from "../components/Message"

export const CounterApp = ()=>{
    // Hook
    const [counter, setCounter] = useState(0);
    console.log('Counter App Component');
    // let counter = 0;
    const plus = ()=>{
        // counter++;
        setCounter(counter + 1);
        console.log('Plus ', counter);
    }
    const minus = ()=>{
        // counter--;
        setCounter(counter - 1);
        console.log('Minus ', counter);
    }
    return(
        <div style={{backgroundColor:'#325500',height:'100vh'}}>
            <Message msg="Counter App"/>
            <Message msg="Count is " val={counter}/>
            <Button fn = {plus} val="+"/>
            <Button fn={minus} val="-"/>
        </div>
    )
}