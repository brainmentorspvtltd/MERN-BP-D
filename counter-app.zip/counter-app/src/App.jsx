

import { CounterApp } from './pages/CounterApp'

function App() {
  return (<CounterApp/>)
}

export default App
