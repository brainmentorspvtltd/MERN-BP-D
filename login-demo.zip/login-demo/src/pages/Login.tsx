import { ChangeEventHandler, useRef, useState } from "react";
import Text from "../components/Text";
import TextBox from "../components/TextBox";
import Button from "../components/Button";

const Login = ()=>{
    const userIdRef= useRef<HTMLInputElement>();
    const passwordRef = useRef<HTMLInputElement>();
    const [errorMessage , setErrorMessage] = useState<string>("");
    const takeUserInput = (event:React.ChangeEvent<HTMLInputElement>)=>{
        // event = Which event happens
        // target = where happens (textbox e.g input type='text')
        // target give source 
        // value - textbox value
        const userid = event.target.value;
        const error = userIdValidation(userid);
        setErrorMessage(error);
       
        //console.log('User Input ', userid);
    }
    const takePasswordInput = (event:React.ChangeEvent<HTMLInputElement>)=>{
        const password = event.target.value;
        
       
        //console.log('Password Input ', password);
    }

    const userIdValidation =(userid:string)=>{
        if(userid.length<3){
            return "Userid Require Min 3 Chars";
        }
        if(userid.length>25){
            return "Userid can't be greater than 25 chars";
        }
        //pattern = /^/d+$/
        //pattern = /^[0-9]{3,10}$/
        const pattern = /^[a-zA-Z][a-zA-Z0-9]*$/;
        const r=new RegExp(pattern);
        console.log('Pattern ', r.test(userid));
        if(r.test(userid)){
            return "";
        }
        else{
            return "Invalid Userid ";
        }
    }

    const mySubmit = (event:any)=>{
        const userid = userIdRef.current?.value;
        const password = passwordRef.current?.value;
        const error = userIdValidation(userid!);
        setErrorMessage(error);
        console.log('Form Submit... '+userid+" "+password);
        event.preventDefault();
    }

    return (<form onSubmit={mySubmit}>
        <h1>Login </h1>
        <Text lbl="Userid"/>
        <TextBox myref={userIdRef} fieldType="text" placeHolder="Type Userid Here" 
        fn={takeUserInput} />
        <Text lbl = {errorMessage}/>    
        <br />
        <Text lbl = "Password"/>
        <TextBox myref={passwordRef} fieldType="password" placeHolder="Type Password Here" 
        fn={takePasswordInput} />
        <br />
        <Button label="Login"/>
        &nbsp;
        <Button label="Reset"/>
    </form>);
}
export default Login;