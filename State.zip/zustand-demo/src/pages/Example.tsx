import { Input } from "../components/Input"
import { Output } from "../components/Output"
import { Sample } from "../components/Sample";


export const Example = () => {
    console.log('Example Component Render');
  return (
    <div>
        <h1>Zustand Example</h1>
        <Input/>
        <hr />
        <Output/>
        {/* <Sample/> */}
    </div>
  )
}
