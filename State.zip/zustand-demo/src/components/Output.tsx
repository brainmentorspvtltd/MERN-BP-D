import { useMessageStore } from "../store/store"
import { Sample } from "./Sample";


export const Output = () => {
    console.log('Output Component Render');
    const store = useMessageStore();
  return (
    <div><h1>Message is {store.message}</h1>
    <Sample/>
    </div>
  )
}
