

export const Sample = () => {
    console.log('Sample Component Render');
  return (
    <div>This is Just Sample Component</div>
  )
}
