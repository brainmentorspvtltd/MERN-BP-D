import { ChangeEvent } from "react"
import { useMessageStore } from "../store/store";


export const Input = () => {
    console.log('Input Component Render');
    const store = useMessageStore();
    const takeInput = (event:ChangeEvent<HTMLInputElement>)=>{
        const r = event.target.value;
        store.setMessage(r);

    }
  return (
    <div>
        <input type="text" placeholder="Type Your Message Here" onChange={takeInput} />
    </div>
  )
}
