import { create } from "zustand";
interface ShareType {
    message:string;
    setMessage:(msg:string)=>void;
}
export const useMessageStore = 
create<ShareType>((set)=>({
    message:'',
    setMessage :(msg:string)=>
    set((state)=>({message :  msg}))
}))