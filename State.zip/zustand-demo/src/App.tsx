import { Example } from "./pages/Example"

const App = ()=>{
  console.log('App Component Render');
  return (<Example/>)
}
export default App;