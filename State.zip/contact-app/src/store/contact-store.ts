import { create } from "zustand";

type Person = {
    email:string;
    phone:string;
    address:string;
}
interface PersonType{
    persons:Person[],
    addPerson:(person:Person)=>void;
    // removePerson:()=>number;
    // searchPerson:()=>boolean;
}
export const usePersonStore = create<PersonType>((set)=>({
    persons:[],
    addPerson:(person:Person)=>set((state)=>({persons:[...state.persons, person]}))

}));