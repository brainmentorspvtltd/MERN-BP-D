import React from 'react'
import { PersonForm } from '../components/PersonForm'
import { PersonList } from '../components/PersonList'

export const PersonDetails = () => {
  return (
    <>
        <PersonForm/>
        <PersonList/>
    </>
  )
}
