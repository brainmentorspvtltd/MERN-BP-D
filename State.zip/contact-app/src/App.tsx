import { PersonDetails } from "./pages/PersonDetails"

const App = ()=>{
  return (<PersonDetails/>)
}
export default App;