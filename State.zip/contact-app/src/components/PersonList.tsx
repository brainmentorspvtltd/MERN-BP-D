import { usePersonStore } from "../store/contact-store"


export const PersonList = () => {
   const store =  usePersonStore();
  return (
    <div>
        <h2>Person List</h2>
        <table style={{borderWidth:'2px',borderColor:'black',borderStyle:"solid"}}>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Phone</th>
                </tr>
            </thead>
            <tbody>
            {store.persons.map((person, index)=><tr>
                <td>{index + 1}</td>
                <td>{person.email}</td>
                <td>{person.phone}</td>
                <td>{person.address}</td>
                </tr>)}   
            </tbody>
        </table>
        
    </div>
  )
}
