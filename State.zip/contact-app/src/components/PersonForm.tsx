import { useRef } from "react"
import { usePersonStore } from "../store/contact-store";


export const PersonForm = () => {
  const emailRef = useRef<HTMLInputElement>(null);  
  const phoneRef = useRef<HTMLInputElement>(null);  
  const addressRef = useRef<HTMLInputElement>(null);  
  const store = usePersonStore();
  const addPerson = ()=>{
      const person = {email: emailRef.current?.value!,
         phone : phoneRef.current?.value!, 
         address: addressRef.current?.value!};  
      store.addPerson(person);   
  }
  return (
    <div>
        <h1>Person Form</h1>
        <input ref= {emailRef} type="text" placeholder="Type Email Here"/>
        <br />
        <input ref = {phoneRef} type="text" placeholder="Type Phone Here" />
        <br />
        <input ref = {addressRef} type="text" placeholder="Type Address" />
        <br />
        <button onClick={addPerson}>Add Person</button>
    </div>
  )
}
