import { useContext } from "react";
import { CounterContext } from "../context/counter-context";

type ButtonProps = {
    label:string;
}

const Button = (props:ButtonProps) => {
    const context = useContext(CounterContext);
  return (
    <button onClick={context.plus}>{props.label}</button>
  )
}

export default Button