import { useContext } from "react"
import { CounterContext } from "../context/counter-context"


export const Message = () => {
    const context = useContext(CounterContext);
  return (
    <div>Count is {context.count}</div>
  )
}
