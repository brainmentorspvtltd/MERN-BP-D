import { useState } from "react";
import { CounterContext } from "./context/counter-context"
import { CounterApp } from "./pages/CounterApp"



function App() {
  const [count , setCount ] = useState<number>(0);
  const plus = ()=>{
    console.log('Plus ....');
    setCount(count + 1); // Re-Render
  }
  const minus = ()=>{
    console.log('Minus ....');
    setCount(count - 1);
  }

  return (
    <CounterContext.Provider value={{count, plus, minus}}>
      <CounterApp/>
      
    </CounterContext.Provider>  
  )
}

export default App
