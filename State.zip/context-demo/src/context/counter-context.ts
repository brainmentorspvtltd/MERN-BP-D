import { createContext } from "react";

// Step - 1  Define Type
interface CounterData{
    count:number;
    plus:()=>void;
    minus:()=>void;
}

// Step - 2 Create Context
export const CounterContext = createContext<CounterData>({count:0, plus:function(){}, minus:function(){}});