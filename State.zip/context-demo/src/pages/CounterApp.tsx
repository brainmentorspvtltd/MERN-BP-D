import Button from "../components/Button"
import { Message } from "../components/Message"


export const CounterApp = () => {
  return (
    <div>
        <h1>Counter App</h1>
        <Message/>
        <Button label="+"/>
        <Button label="-"/>
    </div>
  )
}
