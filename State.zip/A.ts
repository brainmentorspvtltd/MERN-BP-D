let x:string = "Amit";
x = "Amit";
let y:(a:number, b:number)=>number = function(a:number,b:number):number{
    return a + b;
};
// y = function(a:number){

// }
y = function(a,b){
    return a + b;
}