import { productOperations } from "../../products/services/product-service.js";
import { cartOperations } from "../services/cart-operations.js";

window.addEventListener('load', bindEvents);
// Service / Model and View
function bindEvents(){
    document.querySelector('#add-to-cart').addEventListener('click', addToCart);
}

function addToCart(){
    // Get the Product Id from the URL
    // look up the Product id in the product array (Product Service)
    // product found then add in cart (Cart Service)
    const url = new URLSearchParams(location.href);
    const productId = url.entries().next().value[1];
    const product = productOperations.searchProduct(productId);
    console.log('Add to cart call ', product);
    cartOperations.addToCart(product);



}