import { apiCall } from "../../../shared/services/api-client.js"
import { PRODUCT_URL } from "../../../shared/utils/config.js"
import Product from "../models/product.js";

// Bring the Products from the BackEnd Api
export const getProducts = async ()=>{
    const rawProducts = await apiCall(PRODUCT_URL);
    const products = rawProducts.map(product=>
        new Product(product.id, product.title, 
            product.description,product.price, product.image));
    console.log('Products are ', products);
    return products;
}