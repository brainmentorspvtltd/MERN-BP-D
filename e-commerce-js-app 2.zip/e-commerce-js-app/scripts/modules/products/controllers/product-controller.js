// It is a Glue b/w view (HTML) and Service (Model)
// Controller Connect View and Model
// DOM Handling

import { productOperations } from "../services/product-service.js";


/*
 <div class="card me-2" style="width: 18rem;">
                <img src="https://www.jiomart.com/images/product/original/rvrgwpjvsp/bruton-trendy-sports-shoes-for-men-blue-product-images-rvrgwpjvsp-0-202209021256.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Shoe</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-primary">See More</a>
                </div>
              </div>
*/
const fetchProducts = async ()=>{
    const products = await productOperations.getProducts();
    // store the products
    if(localStorage){
      localStorage.products = JSON.stringify(products);
    }
    else{
      alert("Outdated browser can't have localstorage option");
    }
    products.forEach(createProductCard);
    //products.forEach(product=>createProductCard(product));
    console.log('All Products Rec in Controller ', products);
}
const createProductCard = (product)=>{
    const productsDiv = document.querySelector('#products');
    const cardDiv = document.createElement('div');
    cardDiv.className='card me-2';
    cardDiv.style.width = "18rem";
    const image = document.createElement('img');
    image.src = product.image;
    image.className = 'card-img-top';
    image.style.width='200px';
    image.style.height='200px';
    cardDiv.appendChild(image);
    //productsDiv.appendChild(cardDiv);
    const cardBody = document.createElement('div');
    cardBody.className = 'card-body';
    const h5 = document.createElement('h5');
    h5.className = 'card-title';
    h5.innerText  = product.name;
    const p = document.createElement('p');
    p.className = 'card-text';
    p.innerText = product.desc.substring(0,50)+"........";
    const aTag = document.createElement('a');
    aTag.href = 'product-detail.html?id='+product.id;
    aTag.className = 'text-decoration-none';
    aTag.style.width = "18rem";
    // aTag.className = 'btn btn-primary';
    // aTag.innerText = 'Buy';
    cardBody.appendChild(h5);
    cardBody.appendChild(p);
    //cardBody.appendChild(aTag);
    cardDiv.appendChild(cardBody);
    aTag.appendChild(cardDiv);
    productsDiv.appendChild(aTag);


                 

}
fetchProducts();