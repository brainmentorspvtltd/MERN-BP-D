import { doPayment } from "../services/payment.js";
window.addEventListener('load', ()=>{
    document.querySelector('#buy').addEventListener('click', function(e){
        doPayment(5000);
       // e.preventDefault();
    });
})
