export const PRODUCT_URL = 'https://fakestoreapi.com/products';
export const PAYMENT_API_KEY = 'rzp_test_xQJcS49E6NLbJj';