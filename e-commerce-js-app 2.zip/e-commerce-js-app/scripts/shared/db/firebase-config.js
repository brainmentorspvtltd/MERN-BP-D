
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyC02h8W2NGhuvqs4mw8HyXC2_qpj4WRumc",
    authDomain: "e-commerce-db-b18e4.firebaseapp.com",
    projectId: "e-commerce-db-b18e4",
    storageBucket: "e-commerce-db-b18e4.appspot.com",
    messagingSenderId: "604450761466",
    appId: "1:604450761466:web:9abc6fa81b0ba2c6fc7743",
    measurementId: "G-771BVHXJXD"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
